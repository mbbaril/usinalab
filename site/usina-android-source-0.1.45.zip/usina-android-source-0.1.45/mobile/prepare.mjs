// SPDX-License-Identifier: GPL-3.0-only
// Copyright (C) 2026 Mario Baril
import { copyFile, access } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
const root = new URL('../', import.meta.url);
await access(new URL('build-web/dist/usina.wasm', root));
await copyFile(new URL('node_modules/@capacitor/core/dist/index.js', import.meta.url), new URL('build-web/dist/capacitor-core.js', root));
await copyFile(new URL('node_modules/@capacitor/core/LICENSE', import.meta.url), new URL('build-web/dist/Capacitor-LICENSE.txt', root));
console.log(`Mobile web assets prepared in ${fileURLToPath(new URL('build-web/dist', root))}`);
