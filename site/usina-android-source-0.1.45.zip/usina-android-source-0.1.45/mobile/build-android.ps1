# SPDX-License-Identifier: GPL-3.0-only
# Copyright (C) 2026 Mario Baril
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path $PSScriptRoot -Parent
& wsl --cd $projectRoot -e bash web/build.sh
if ($LASTEXITCODE -ne 0) { throw 'WebAssembly build failed.' }
Push-Location $PSScriptRoot
try {
    if (-not (Test-Path -LiteralPath (Join-Path $PSScriptRoot 'node_modules/@capacitor/cli'))) {
        & npm ci --no-audit --no-fund
        if ($LASTEXITCODE -ne 0) { throw 'Mobile dependencies failed.' }
    }
    & npm run prepare:web
    if ($LASTEXITCODE -ne 0) { throw 'Web asset preparation failed.' }
    & npx cap sync android
    if ($LASTEXITCODE -ne 0) { throw 'Android sync failed.' }
} finally { Pop-Location }
& wsl --cd (Join-Path $PSScriptRoot 'android') -e bash -lc 'export ANDROID_HOME="${ANDROID_HOME:-$HOME/Android/sdk}"; bash gradlew :app:assembleDebug --console=plain'
if ($LASTEXITCODE -ne 0) { throw 'APK build failed.' }
$deliveryDir = Join-Path $projectRoot 'deliverables'
New-Item -ItemType Directory -Force -Path $deliveryDir | Out-Null
$version = (Get-Content -LiteralPath (Join-Path $PSScriptRoot 'package.json') -Raw | ConvertFrom-Json).version
$apk = Join-Path $deliveryDir "Usina-Lab-$version-android-debug.apk"
$builtApk = Join-Path $PSScriptRoot 'android/app/build/outputs/apk/debug/app-debug.apk'
$validated = Join-Path $deliveryDir "android-runtime-tests-$version.validation.json"
if (Test-Path -LiteralPath $validated) {
    $evidence = Get-Content -LiteralPath $validated -Raw | ConvertFrom-Json
    $builtHash = (Get-FileHash -LiteralPath $builtApk -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($builtHash -ne $evidence.apkSha256) { throw "Version $version already has a validated artifact. Increment the version before delivering changed code." }
}
Copy-Item -LiteralPath $builtApk -Destination $apk -Force
Get-FileHash -LiteralPath $apk -Algorithm SHA256 | Format-List
Write-Output "Installable test APK: $apk"
