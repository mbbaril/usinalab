package br.art.ruido.usina.lab;

import com.getcapacitor.BridgeActivity;
import android.os.Bundle;

public class MainActivity extends BridgeActivity {
    @Override public void onCreate(Bundle savedInstanceState) {
        registerPlugin(UsinaMidiPlugin.class);
        registerPlugin(UsinaStoragePlugin.class);
        registerPlugin(UsinaHapticsPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
