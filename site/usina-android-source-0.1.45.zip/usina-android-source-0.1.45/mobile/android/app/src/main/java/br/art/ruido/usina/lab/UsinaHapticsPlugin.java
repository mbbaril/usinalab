// SPDX-License-Identifier: GPL-3.0-only
package br.art.ruido.usina.lab;
import android.view.HapticFeedbackConstants;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.JSObject;
import com.getcapacitor.annotation.CapacitorPlugin;

/** Uses system touch feedback, respects the user's device settings, no vibration permission. */
@CapacitorPlugin(name="UsinaHaptics")
public class UsinaHapticsPlugin extends Plugin {
    @PluginMethod public void pulse(PluginCall call) {
        getActivity().runOnUiThread(() -> {
            JSObject result = new JSObject();
            result.put("performed", getBridge().getWebView().performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP));
            call.resolve(result);
        });
    }
}
