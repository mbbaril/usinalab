// SPDX-License-Identifier: GPL-3.0-only
// Copyright (C) 2026 Mario Baril
package br.art.ruido.usina.lab;
import android.app.Activity;
import android.content.Intent;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.ActivityCallback;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

@CapacitorPlugin(name="UsinaStorage")
public class UsinaStoragePlugin extends Plugin {
    @PluginMethod public void save(PluginCall call) {
        String text=call.getString("text");
        if(text==null||text.length()>2*1024*1024){call.reject("Sessão inválida.");return;}
        Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        String name=call.getString("name","usina-session.json");
        if(name.length()>100||name.contains("/")||name.contains("\\")||!(name.endsWith(".json")||name.endsWith(".usinamap")||name.endsWith(".usina"))){call.reject("Nome de arquivo inválido.");return;}
        intent.setType(name.endsWith(".json")?"application/json":"application/xml");
        intent.putExtra(Intent.EXTRA_TITLE,name);
        startActivityForResult(call,intent,"saved");
    }
    @ActivityCallback private void saved(PluginCall call,ActivityResult result) {
        if(call==null)return;
        if(result.getResultCode()!=Activity.RESULT_OK||result.getData()==null||result.getData().getData()==null){call.reject("Salvamento cancelado.");return;}
        try(OutputStream output=getContext().getContentResolver().openOutputStream(result.getData().getData(),"wt")) {
            if(output==null)throw new java.io.IOException("Arquivo indisponível");
            output.write(call.getString("text","").getBytes(StandardCharsets.UTF_8));
            call.resolve();
        }catch(Exception error){call.reject("Não foi possível salvar a sessão: "+error.getMessage());}
    }
}
