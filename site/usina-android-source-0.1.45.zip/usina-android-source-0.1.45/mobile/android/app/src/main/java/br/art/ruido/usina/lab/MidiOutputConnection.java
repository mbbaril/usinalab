// SPDX-License-Identifier: GPL-3.0-only
package br.art.ruido.usina.lab;

import android.media.midi.MidiDevice;
import android.media.midi.MidiInputPort;
import android.os.Handler;
import android.os.HandlerThread;
import com.getcapacitor.JSObject;
import com.getcapacitor.PluginCall;
import java.io.IOException;
import java.util.BitSet;
import java.util.function.Consumer;

/** The selected destination only. All port IO runs on one worker, outside UI/audio callbacks. */
final class MidiOutputConnection {
    private final HandlerThread thread = new HandlerThread("UsinaMidiOutput");
    private final Handler worker;
    private final Consumer<JSObject> changed;
    private final BitSet[] notes = new BitSet[16];
    private final Object queueLock = new Object();
    private int queuedBytes, usedChannels;
    private volatile boolean destroyed;
    private MidiInputPort port;
    private int deviceId = -1, portNumber = -1;
    MidiOutputConnection(Consumer<JSObject> listener) {
        changed=listener; for(int c=0;c<16;++c)notes[c]=new BitSet(128);
        thread.start();worker=new Handler(thread.getLooper());
    }
    private JSObject state(String message) { return new JSObject().put("deviceId",deviceId).put("port",portNumber).put("ready",port!=null).put("message",message); }
    void select(MidiDevice device,int number,PluginCall call) {
        worker.post(() -> {
            if(destroyed){call.reject("Saída MIDI encerrada.");return;}
            if(deviceId==device.getInfo().getId()&&portNumber==number&&port!=null){call.resolve(state("Saída MIDI selecionada."));return;}
            try {
                MidiInputPort next=device.openInputPort(number);
                if(next==null){call.reject("A porta está ocupada ou indisponível.");return;}
                release(); closePort();port=next;deviceId=device.getInfo().getId();portNumber=number;
                JSObject result=state("Saída MIDI conectada.");changed.accept(result);call.resolve(result);
            }catch(RuntimeException error){call.reject("Não foi possível abrir a saída MIDI: "+error.getMessage());}
        });
    }
    void send(byte[] bytes,PluginCall call) {
        synchronized(queueLock){if(destroyed||queuedBytes+bytes.length>8192){call.reject("Fila de saída MIDI cheia ou encerrada.");return;}queuedBytes+=bytes.length;}
        worker.post(() -> {
            synchronized(queueLock){queuedBytes-=bytes.length;}
            if(port==null||destroyed){call.reject("Escolha uma saída MIDI antes de tocar.");return;}
            try { port.send(bytes,0,bytes.length);track(bytes);call.resolve(); }
            catch(IOException|RuntimeException error){release();closePort();changed.accept(state("Saída MIDI desconectada."));call.reject("Falha no envio MIDI: "+error.getMessage());}
        });
    }
    private void track(byte[] bytes) {
        for(int i=0;i<bytes.length;){int s=bytes[i++]&255,c=s&15,k=s&240,a=bytes[i++]&127,b=k==0xd0?0:bytes[i++]&127;
            if(k==0x90&&b>0){notes[c].set(a);usedChannels|=1<<c;}
            else if(k==0x80||k==0x90)notes[c].clear(a);
            else if(k==0xe0||k==0xd0||k==0xb0&&a==74)usedChannels|=1<<c;
            else if(k==0xb0&&(a==120||a==123))notes[c].clear();
        }
    }
    private void release() {
        if(port!=null)try {
            for(int c=0;c<16;++c) {
                for(int n=notes[c].nextSetBit(0);n>=0;n=notes[c].nextSetBit(n+1))port.send(new byte[]{(byte)(0x80+c),(byte)n,0},0,3);
                if((usedChannels&(1<<c))!=0){
                    port.send(new byte[]{(byte)(0xb0+c),123,0,(byte)(0xd0+c),0,(byte)(0xe0+c),0,64,(byte)(0xb0+c),74,64},0,11);
                }
            }
        }catch(IOException|RuntimeException ignored){}
        for(BitSet n:notes)n.clear();usedChannels=0;
    }
    private void closePort(){if(port!=null)try{port.close();}catch(IOException ignored){}port=null;deviceId=portNumber=-1;}
    void panic(PluginCall call){worker.post(()->{release();if(port!=null)changed.accept(state("").put("released",true));if(call!=null)call.resolve();});}
    void closeDevice(int id){worker.post(()->{if(deviceId==id){release();closePort();changed.accept(state("Destino MIDI removido."));}});}
    void disconnect(PluginCall call){worker.post(()->{release();closePort();changed.accept(state("Saída MIDI fechada."));call.resolve();});}
    void shutdown(Runnable finished){destroyed=true;worker.post(()->{release();closePort();finished.run();thread.quitSafely();});}
}
