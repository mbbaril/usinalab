// SPDX-License-Identifier: GPL-3.0-only
// Copyright (C) 2026 Mario Baril
package br.art.ruido.usina.lab;

import android.Manifest;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.pm.PackageManager;
import android.media.midi.MidiDevice;
import android.media.midi.MidiDeviceInfo;
import android.media.midi.MidiManager;
import android.media.midi.MidiOutputPort;
import android.media.midi.MidiReceiver;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelUuid;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

@CapacitorPlugin(name = "UsinaMidi", permissions = {
    @Permission(alias = "ble", strings = {Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}),
    @Permission(alias = "location", strings = {Manifest.permission.ACCESS_FINE_LOCATION})
})
public class UsinaMidiPlugin extends Plugin {
    private MidiManager manager;
    private MidiOutputConnection outgoing;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Map<Integer, MidiDevice> devices = new HashMap<>();
    private final Map<Integer, List<MidiOutputPort>> ports = new HashMap<>();
    private final Set<Integer> opening = new HashSet<>();
    private final List<BluetoothDevice> discovered = new ArrayList<>();
    private BluetoothAdapter adapter;
    private ScanCallback scanner;
    private boolean started = false;
    private boolean destroyed = false;
    private int pendingBytes = 0;
    private boolean overflowPosted = false;
    private static final int MAX_QUEUED_BYTES = 16384;
    private final MidiManager.DeviceCallback deviceCallback = new MidiManager.DeviceCallback() {
        @Override public void onDeviceAdded(MidiDeviceInfo info) { open(info); announce(); }
        @Override public void onDeviceRemoved(MidiDeviceInfo info) { close(info.getId()); announce(); }
    };
    @Override public void load() {
        manager = (MidiManager)getContext().getSystemService(Context.MIDI_SERVICE);
        BluetoothManager bm = (BluetoothManager)getContext().getSystemService(Context.BLUETOOTH_SERVICE);
        adapter = bm == null ? null : bm.getAdapter();
        outgoing=new MidiOutputConnection(state -> handler.post(() -> {if(!destroyed)notifyListeners("output",state);}));
    }
    @PluginMethod public void connect(PluginCall call) {
        if(manager == null || !getContext().getPackageManager().hasSystemFeature(PackageManager.FEATURE_MIDI)) {call.reject("Este aparelho não oferece o serviço MIDI Android.");return;}
        handler.post(() -> {
            if(!started) { manager.registerDeviceCallback(deviceCallback, handler); started = true; }
            for(MidiDeviceInfo info : manager.getDevices()) open(info);
            call.resolve();
        });
    }
    private void open(MidiDeviceInfo info) {
        if(devices.containsKey(info.getId()) || !opening.add(info.getId())) return;
        try { manager.openDevice(info, device -> {
            opening.remove(info.getId());
            if(device != null) attach(device);
        }, handler); } catch(SecurityException error) { opening.remove(info.getId()); }
    }
    private void attach(MidiDevice device) {
        int id = device.getInfo().getId();
        if(destroyed || devices.containsKey(id)) {try {device.close();}catch(IOException ignored){}return;}
        devices.put(id, device);
        List<MidiOutputPort> outputs = new ArrayList<>();
        // Android calls the instrument's transmitting ports OUTPUT. These feed the Usina INPUT.
        for(MidiDeviceInfo.PortInfo p : device.getInfo().getPorts()) {
            if(p.getType() != MidiDeviceInfo.PortInfo.TYPE_OUTPUT) continue;
            MidiOutputPort output = device.openOutputPort(p.getPortNumber());
            if(output == null) continue;
            final String source = id + ":" + p.getPortNumber();
            output.connect(new MidiReceiver() {
                @Override public void onSend(byte[] data, int offset, int count, long timestamp) {
                    if(count <= 0 || count > MAX_QUEUED_BYTES || destroyed) return;
                    synchronized(UsinaMidiPlugin.this) {
                        if(pendingBytes + count > MAX_QUEUED_BYTES) {
                            if(!overflowPosted) { overflowPosted=true; handler.post(() -> { synchronized(UsinaMidiPlugin.this){overflowPosted=false;} notifyListeners("devices", new JSObject().put("message", "Fila MIDI cheia: notas liberadas.")); }); }
                            return;
                        }
                        pendingBytes += count;
                    }
                    byte[] copy = java.util.Arrays.copyOfRange(data, offset, offset + count);
                    handler.post(() -> {
                        synchronized(UsinaMidiPlugin.this) { pendingBytes -= copy.length; }
                        if(destroyed) return;
                        JSArray bytes = new JSArray(); for(byte b : copy) bytes.put(b & 255);
                        notifyListeners("midi", new JSObject().put("id", source).put("bytes", bytes));
                    });
                }
            });
            outputs.add(output);
        }
        ports.put(id, outputs); announce();
    }
    private void close(int id) {
        if(outgoing!=null)outgoing.closeDevice(id);
        List<MidiOutputPort> output = ports.remove(id);
        if(output != null) for(MidiOutputPort p : output) try {p.close();}catch(IOException ignored){}
        MidiDevice device = devices.remove(id); if(device != null) try {device.close();}catch(IOException ignored){}
    }
    private void announce() { notifyListeners("devices", new JSObject().put("message", "Dispositivos MIDI atualizados.")); }
    @PluginMethod public void devices(PluginCall call) {
        handler.post(() -> { JSArray list = new JSArray();
            for(MidiDevice device : devices.values()) { MidiDeviceInfo info = device.getInfo();
                String name = info.getProperties().getString(MidiDeviceInfo.PROPERTY_NAME, "MIDI");
                JSArray inputs=new JSArray();for(MidiDeviceInfo.PortInfo p:info.getPorts())if(p.getType()==MidiDeviceInfo.PortInfo.TYPE_INPUT)inputs.put(new JSObject().put("port",p.getPortNumber()).put("name",p.getName()));
                list.put(new JSObject().put("id", info.getId()).put("name", name).put("ble", info.getType() == MidiDeviceInfo.TYPE_BLUETOOTH).put("inputs",inputs));
            }
            call.resolve(new JSObject().put("devices", list));
        });
    }
    @PluginMethod public void selectOutput(PluginCall call) {
        Integer id=call.getInt("deviceId"),number=call.getInt("port");
        if(id==null||number==null||number<0){call.reject("Destino MIDI inválido.");return;}
        handler.post(()->{MidiDevice device=devices.get(id);if(device==null){call.reject("O dispositivo MIDI não está conectado.");return;}boolean found=false;for(MidiDeviceInfo.PortInfo p:device.getInfo().getPorts())if(p.getType()==MidiDeviceInfo.PortInfo.TYPE_INPUT&&p.getPortNumber()==number)found=true;if(!found){call.reject("Porta MIDI inválida.");return;}outgoing.select(device,number,call);});
    }
    @PluginMethod public void sendOutput(PluginCall call) {
        JSArray messages=call.getArray("messages");
        if(messages==null||messages.length()<1||messages.length()>256){call.reject("Lote MIDI inválido.");return;}
        try {
            java.io.ByteArrayOutputStream bytes=new java.io.ByteArrayOutputStream(768);
            for(int i=0;i<messages.length();++i){org.json.JSONArray m=messages.getJSONArray(i);if(m.length()<2||m.length()>3)throw new IllegalArgumentException();
                for(int j=0;j<m.length();++j)if(!(m.get(j) instanceof Number)||m.getDouble(j)!=m.getInt(j))throw new IllegalArgumentException();
                int s=m.getInt(0),a=m.getInt(1),b=m.length()>2?m.getInt(2):0,k=s&240;
                if(s<0x80||s>=0xf0||!(k==0x80||k==0x90||k==0xb0||k==0xd0||k==0xe0)||a<0||a>127||b<0||b>127||k!=0xd0&&m.length()!=3)throw new IllegalArgumentException();
                bytes.write(s);bytes.write(a);if(k!=0xd0)bytes.write(b);
            }
            outgoing.send(bytes.toByteArray(),call);
        }catch(Exception invalid){call.reject("Mensagens MIDI inválidas.");}
    }
    @PluginMethod public void panicOutput(PluginCall call){outgoing.panic(call);}
    @PluginMethod public void disconnectOutput(PluginCall call){outgoing.disconnect(call);}
    @PluginMethod public void bluetooth(PluginCall call) {
        String permission = Build.VERSION.SDK_INT >= 31 ? "ble" : "location";
        if(getPermissionState(permission) != PermissionState.GRANTED) { requestPermissionForAlias(permission, call, "bluetoothPermission"); return; }
        scan(call);
    }
    @PermissionCallback private void bluetoothPermission(PluginCall call) {
        String permission = Build.VERSION.SDK_INT >= 31 ? "ble" : "location";
        if(getPermissionState(permission) != PermissionState.GRANTED) {call.reject("Permissão Bluetooth não concedida.");return;}
        scan(call);
    }
    private void scan(PluginCall call) {
        handler.post(() -> {
            try {
                if(adapter == null || !adapter.isEnabled()) {call.reject("Ative o Bluetooth do aparelho.");return;}
                android.bluetooth.le.BluetoothLeScanner leScanner=adapter.getBluetoothLeScanner();
                if(leScanner==null){call.reject("Bluetooth indisponível. Ative-o e tente novamente.");return;}
                if(scanner != null) {call.reject("Uma busca MIDI BLE já está em andamento.");return;}
                discovered.clear();
                scanner = new ScanCallback() {
                    @Override public void onScanResult(int type, ScanResult result) {if(!discovered.contains(result.getDevice())) discovered.add(result.getDevice());}
                    @Override public void onScanFailed(int code) {stopScan();call.reject("Falha na busca MIDI BLE: " + code);}
                };
                ScanFilter filter = new ScanFilter.Builder().setServiceUuid(new ParcelUuid(UUID.fromString("03b80e5a-ede8-4b33-a751-6ce34ec4c700"))).build();
                leScanner.startScan(Collections.singletonList(filter), new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(), scanner);
                handler.postDelayed(() -> {
                    if(scanner == null) return;
                    stopScan();
                    if(discovered.isEmpty()) {call.reject("Nenhum dispositivo MIDI BLE encontrado. Ative o modo BLE do SMK37, SMC ou FM-1 e tente novamente.");return;}
                    CharSequence[] names = new CharSequence[discovered.size()];
                    for(int i=0;i<names.length;++i) {BluetoothDevice d=discovered.get(i);names[i]=d.getName()==null?d.getAddress():d.getName();}
                    new AlertDialog.Builder(getActivity()).setTitle("Conectar MIDI BLE").setItems(names, (dialog, which) -> {
                        try { manager.openBluetoothDevice(discovered.get(which), device -> {
                            if(device == null) {call.reject("Não foi possível abrir o dispositivo MIDI BLE.");return;}
                            attach(device);call.resolve();
                        }, handler); } catch(RuntimeException error) {call.reject("Não foi possível conectar MIDI BLE: "+error.getMessage());}
                    }).setNegativeButton("Cancelar", (dialog, which) -> call.resolve()).setOnCancelListener(dialog -> call.resolve()).show();
                }, 5000);
            } catch(RuntimeException error) {stopScan();call.reject("Bluetooth indisponível ou sem permissão: "+error.getMessage());}
        });
    }
    private void stopScan() {
        if(scanner != null && adapter != null) try {android.bluetooth.le.BluetoothLeScanner le=adapter.getBluetoothLeScanner();if(le!=null)le.stopScan(scanner);}catch(RuntimeException ignored){}
        scanner = null;
    }
    @Override protected void handleOnDestroy() {
        destroyed = true; stopScan();
        if(started && manager != null) manager.unregisterDeviceCallback(deviceCallback);
        handler.removeCallbacksAndMessages(null);
        outgoing.shutdown(()->handler.post(()->{for(List<MidiOutputPort> list:ports.values())for(MidiOutputPort port:list)try{port.close();}catch(IOException ignored){}for(MidiDevice device:new ArrayList<>(devices.values()))try{device.close();}catch(IOException ignored){}devices.clear();ports.clear();}));
    }
    @Override protected void handleOnPause(){if(outgoing!=null)outgoing.panic(null);}
}
