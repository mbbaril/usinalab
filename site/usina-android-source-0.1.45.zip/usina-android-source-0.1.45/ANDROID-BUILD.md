# Usina Lab — fontes Android 0.1.45

Fontes do aplicativo correspondente ao APK Usina-Lab-0.1.45-android-debug.apk (SHA-256 26e6517452bb0035bd8a644ff9369ac469c50fd958fc5df369d8059f6745cef8). Não afirma correspondência com versões antigas não identificadas.

Inclui UI, adaptador/DSP, fontes RuídoCore, pontes Java de MIDI/armazenamento/háptica, recursos/manifesto Android, Gradle wrapper, versões npm fixadas e fontes Capacitor Android/core 8.5.3. Bancos FM pessoais, histórico Git, credenciais, signing keys, caches e caminhos de SDK locais ficam excluídos.

Windows/WSL: instalar Java 21, Android SDK 36/build-tools 35.0.0 (aceitar as licenças diretamente no SDK), CMake, Emscripten 4.0.23 e Node.js. No PowerShell, executar mobile/build-android.ps1. O script compila WASM, instala as versões npm do package-lock, prepara/sincroniza Capacitor e executa assembleDebug no WSL. Configurar ANDROID_HOME/EMSDK conforme seu ambiente. Não é necessário copiar o repositório privado de desenvolvimento.

Linux: bash web/build.sh; cd mobile; npm ci; npm run prepare:web; npx cap sync android; cd android; ANDROID_HOME=/seu/sdk bash gradlew :app:assembleDebug. Os plugins/dependências Java AndroidX/Cordova/Gradle são resolvidos pelos repositórios google/Maven Central conforme mobile/android/variables.gradle e arquivos Gradle. Java/SDK/NDK e ferramentas não são redistribuídos como parte deste pacote. Textos e avisos de licenças acompanham as fontes e os assets. O build de terceiros usa suas próprias chaves de debug; a assinatura privada do APK distribuído não é publicada.

A comprovação desta versão é de fontes/build. A conferência de todas as obrigações/licenças transitivas Android deve continuar no inventário de dependências; versões anteriores distribuídas a quatro pessoas ainda precisam de identificação.
